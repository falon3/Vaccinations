package org.openmrs.module.vaccinations.util;

/**
 * Created by ICCHANGE on 23/Jun/2015.
 */
public class Constants {
    public static final String LOCATIONPROPERTY = "defaultLocation";
}
